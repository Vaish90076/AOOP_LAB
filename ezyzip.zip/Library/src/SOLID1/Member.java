package SOLID1;

public abstract class Member {
	 private String name;
	 private String memberId;
	public Member(String name, String memberId) {
		this.name = name;
        this.memberId = memberId;
	}
	 public String getName() {
	        return name;
	    }
	    public String getMemberId() {
	        return memberId;
	    }
	    public abstract void borrowBook(Book book);
	    public abstract void returnBook(Book book);
}		
		

