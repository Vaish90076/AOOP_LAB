package SOLID1;

public interface Notifications {
	void notify(String message);
}
