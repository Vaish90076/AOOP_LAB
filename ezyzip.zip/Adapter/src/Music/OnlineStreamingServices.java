package Music;

public class OnlineStreamingServices {
	 public void streamMusic() {
	        System.out.println("Streaming music online.");
	    }
	
}
