/**
 * 
 */
/**
 * 
 */
module Adapter {
}