package Employees;

public class Robot implements Worker {
	  public void work() {
	        System.out.println("Robot is working.");
	    }
}
