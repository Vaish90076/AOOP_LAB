package Employees;

public class Main8 {

	public static void main(String[] args) {
		 Robot robot = new Robot();
	        robot.work();
	        Human human = new Human();
	        human.work();
	        human.eat();
	}
}
