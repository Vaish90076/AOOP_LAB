package Employees;

public class Main7 {

	public static void main(String[] args) {
		  Bird bird = new Bird();
	        bird.fly();
	        Bird ostrich = new Ostrich();
	      	        ostrich.fly();
	}

}
