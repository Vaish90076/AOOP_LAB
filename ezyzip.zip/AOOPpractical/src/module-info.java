/**
 * 
 */
/**
 * 
 */
module AOOPpractical {
}