package Bike;

public class AuthenticationManager {

	public static final String authManager = null;

	public void authenticate(String string, String string2) {
		System.out.println("Authentication");
	}

	public static AuthenticationManager getInstance() {
				return null;
	}

}
