package Bike;

public interface Vehicle {
 void ride();
}
