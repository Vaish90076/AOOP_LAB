package Bike;

public  class Bike implements Vehicle {
	public void drive() {
        System.out.println("Riding a bike.");
    }

	public void ride() {
	
	}
}
